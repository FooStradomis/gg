typedef enum {
    HidViewSubmenu,
    HidViewKeynote,
    HidViewKeyboard,
    HidViewMedia,
    HidViewMouse,
    HidViewMouseJiggler,
    BtHidViewTikTok,
    HidViewExitConfirm,
} HidView;