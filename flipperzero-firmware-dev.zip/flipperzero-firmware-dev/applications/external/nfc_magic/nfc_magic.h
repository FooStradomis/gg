#pragma once

typedef struct NfcMagic NfcMagic;
