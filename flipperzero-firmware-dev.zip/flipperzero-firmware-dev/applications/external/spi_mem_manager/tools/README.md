This utility can convert nofeletru's UsbAsp-flash's chiplist.xml to C array

Usage:
```bash
    ./chiplist_convert.py chiplist/chiplist.xml
    mv spi_mem_chip_arr.c ../lib/spi/spi_mem_chip_arr.c
```
