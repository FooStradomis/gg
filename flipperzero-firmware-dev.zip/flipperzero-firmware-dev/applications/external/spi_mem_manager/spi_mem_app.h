#pragma once

typedef struct SPIMemApp SPIMemApp;
