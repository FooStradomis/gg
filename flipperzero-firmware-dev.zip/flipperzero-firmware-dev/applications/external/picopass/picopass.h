#pragma once

typedef struct Picopass Picopass;
